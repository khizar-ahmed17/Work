package xmltoobject;

import java.io.FileOutputStream;
import javax.xml.bind.JAXBContext;  
import javax.xml.bind.Marshaller;


public class ObjectToXml {  
	public static void main(String[] args) throws Exception{  
		JAXBContext contextObj = JAXBContext.newInstance(Employee.class);  
		System.out.println("JAXBContext "+contextObj);

		Marshaller marshallerObj = contextObj.createMarshaller();  
		System.out.println("marshallerObj "+marshallerObj);
		marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);  
		
		

		Employee emp1=new Employee(1,"hi Jaiswal",50000);  

		marshallerObj.marshal(emp1, new FileOutputStream("employee.xml"));  

	}  


}
