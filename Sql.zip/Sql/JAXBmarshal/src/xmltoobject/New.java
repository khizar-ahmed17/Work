package xmltoobject;

import java.io.IOException;

import java.io.InputStream;  
import java.net.URL;
import java.net.UnknownHostException;

import net.sf.json.JSON;  
import net.sf.json.xml.XMLSerializer;  
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.json.XML;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;

import com.mongodb.MongoException;




public class New {

	 
	private static final int PRETTY_PRINT_INDENT_FACTOR =3 ;
	

	    public static void main(String[] args) {
	    	String jsonPrettyPrintString = null;
	        URL url = null;
	        InputStream inputStream = null;  
	        try{
	        	
	            url = New.class.getClassLoader().getResource("employee.xml");
	            System.out.println("url:"+url);
	            String xml = IOUtils.toString(url.openStream());
	    
	            JSONObject  xmlJSONObj = XML.toJSONObject(xml);
	            System.out.println("xmlJSONObj"+xmlJSONObj);
	     //       JSON objJson =new XMLSerializer().read(xml);
	      //      System.out.println("JSON data : " + objJson);
	            
	            jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
	            System.out.println("String "+jsonPrettyPrintString);
	            
	            
	        }catch(Exception e){
	            e.printStackTrace();
	        }finally{
	           try {
	                if (inputStream != null) {
	                    inputStream.close();
	                }
	                url = null;
	            } catch (IOException ex) {}
	        }
	        
	        
			Mongo mongoclient=null;
			try {
				mongoclient = new Mongo("localhost" , 27017);
				
				
				
				
				
			} catch (UnknownHostException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (MongoException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			DB db=mongoclient.getDB("test");
			DBCollection dbcol=db.getCollection("mycollection");
			DBCursor cursor=dbcol.find();
			
			
			
	//		String jsonVal="{'audioitem' : 'AU_0023.wav', 'name' : 'PA_0001.xml'}}";
			
	//		String json = "{detail' :"+jsonVal+" }";
			
			
			//String json = "{'audioitem' : 'AU_0023.wav','name' : 'PA_0001.xml'," +
	//				  "'detail' : {'records' : 99, 'index' : 'vps_index1', 'active' : 'true'}}}";


			
			DBObject dbObject = (DBObject)com.mongodb.util.JSON.parse(jsonPrettyPrintString);
					dbcol.insert(dbObject);
			
			
			while(cursor.hasNext())
			{
				System.out.println(cursor.next());
			}
			
			
			System.out.println("Conneceted To Db successfully");
			
			
	    }
}
