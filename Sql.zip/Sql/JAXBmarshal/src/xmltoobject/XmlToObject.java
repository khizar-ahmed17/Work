package xmltoobject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.UnknownHostException;
import javax.xml.bind.JAXBContext;  
import javax.xml.bind.JAXBException;  
import javax.xml.bind.Unmarshaller;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;



import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;

import com.mongodb.MongoException;
import com.mongodb.util.JSON;

import net.sf.json.xml.XMLSerializer;


public class XmlToObject {

	private static final int PRETTY_PRINT_INDENT_FACTOR =3 ;

	public static void main(String[] args) throws JAXBException {
		
			
			Mongo mongoclient=null;
			try {
				mongoclient = new Mongo("localhost" , 27017);
				
				
				
				
				
			} catch (UnknownHostException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (MongoException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			DB db=mongoclient.getDB("test");
			DBCollection dbcol=db.getCollection("mycollection");
			DBCursor cursor=dbcol.find();
			
			
			
			String jsonVal="{'audioitem' : 'AU_0023.wav', 'name' : 'PA_0001.xml'}}";
			
			String json = "{detail' :"+jsonVal+" }";
			
			
			//String json = "{'audioitem' : 'AU_0023.wav','name' : 'PA_0001.xml'," +
	//				  "'detail' : {'records' : 99, 'index' : 'vps_index1', 'active' : 'true'}}}";

					DBObject dbObject = (DBObject)JSON.parse(json);
					dbcol.insert(dbObject);
			
			
			while(cursor.hasNext())
			{
				System.out.println(cursor.next());
			}
			
			
			System.out.println("Conneceted To Db successfully");
			
			
			
		
		try {    
			File file = new File("employee.xml");    
			System.out.println(file.canRead());
		JAXBContext jaxbContext = JAXBContext.newInstance(Employee.class);    
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller(); 
			System.out.println("jaxbUnmarshaller "+jaxbUnmarshaller);
			Employee e=(Employee) jaxbUnmarshaller.unmarshal(file);    
			System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());  

		} catch (JAXBException e) {e.printStackTrace(); }    

	}
}
			
			



