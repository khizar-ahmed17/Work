package xmltoobject;

import java.net.UnknownHostException;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;

public class Find {

	public static void main(String[] args) {

		Mongo mongoclient=null;
		try {
			mongoclient = new Mongo("localhost" , 27017);





		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MongoException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		DB db=mongoclient.getDB("test");
		DBCollection dbcol=db.getCollection("mycollection");
		DBCursor cursor=dbcol.find();
		


//  db.mycollection.find( {"audioitem":"AU_0021.wav"})




		while(cursor.hasNext())
		{
			System.out.println(cursor.next());
		}


		System.out.println("Conneceted To Db successfully");


	}


	// TODO Auto-generated method stub

}
